MUST BE PRINTED IN ABS. PETG and PLA will NOT work. 

This will work on most other machines like the Wanhao i3, i3 Plus, i3 Mini, Anet A2, A6, A8, E10, and E12.

These STL files are property of TH3D and are not licensed for re-distribution. All rights reserved.