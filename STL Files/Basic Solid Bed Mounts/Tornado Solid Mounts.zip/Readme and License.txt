MUST BE PRINTED IN ABS. PETG and PLA will NOT work. If you cannot print ABS you cannot print ABS we offer solid mounts for the Tornado and ALL CR-10 Machines on the site. 

Our CR-10 (all models) mounts have an aluminum core for maximum durability and stability.

These STL files are property of TH3D and are not licensed for re-distribution. All rights reserved.