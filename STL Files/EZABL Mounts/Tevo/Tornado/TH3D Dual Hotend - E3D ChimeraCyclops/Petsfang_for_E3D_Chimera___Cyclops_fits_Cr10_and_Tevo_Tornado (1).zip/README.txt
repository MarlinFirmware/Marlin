                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2947851
Petsfang for E3D Chimera & Cyclops fits Cr10 and Tevo Tornado by dpetsel is licensed under the Creative Commons - Attribution - Non-Commercial - No Derivatives license.
http://creativecommons.org/licenses/by-nc-nd/3.0/

# Summary

<font size="6" color=brown>Petsfang Chimera/Cyclops </font> 

OFFSETS WITH LEFT MODULAR ABL MOUNTS X= -46, -64     Y=0

# RELEASE NOTES BY DATE

9.6.2018
Added a Chimera/Cyclops Duct for Volcano hot ends on the Chimera
********

7.24.2018
Changed the offsets to negative on ABL's since they are on the left.
I was working on the modular right side mounts and incorrectly copied the files. 
The offsets should be correct now.
********

7.10.2018
I am working with Astroleo to tweak final files. Genuine E3D Chimera has side grub screws to adjust the transition tubes. New base files accommodate the clearances needed to access these screws.
I have printed Reverse Base and fit the TH3d Clone Chimera to the reverse base with great clearances and easy access to the grub screws through the fan. The picture I posted shows that mount. It is on a CR10 back plate for reference.

For the TH3D Clone you should flip the heat block so the compression screws are facing up. With the block flipped your heater and thermistor will face to the side giving better wire routing. This will also allow you to clear the eccentric bolt protruding from the back of the back plate on the CR10 and Tornado. 

It's not as much of a problem on a Tornado as the bolt does not stick out as far.


7.8.2018
11 PM.     Front facing base file is up.

7.8.2018
Made all the revisions that I've been getting messages about last couple of days.
This is for the reverse mount Chimera base which most of you are using.

Here are the changes.

Made all the ABL devices modular like my other platforms. Offsets are X-46, -64, y=0.
Brought the EZABL down per your pics and measurements.
Redrew the duct for clearance around the silicone socks and added 2mm vertical adjustment.
Added nut capture features for attaching the duct.
Added clearance between the heat blocks and base bottom.
Pulled entire Chimera position forward 5mm to clear the back eccentric bolt/nut better.
Files are up with a V7.8 designation.
Dave

6.23.2018
Added a little clearance for the TH3D Chimera dual nozzle mod.

*****
6.6.2018
Added files called Reverse Cyclops. 
These files allow you to mount the Chimera/Cyclops with the heat sink facing backwards allowing you access to the grub screws. You may or may not want this as E3D recommends you have the entire assembly together before mounting. This large internal ducting still captures all the heat sink air and exhausts it out of the side duct. See cutaway pics.
*****
<img src="https://cdn.thingiverse.com/renders/f7/18/be/41/b1/da36d158aac24e5416726c946b53e7fd_preview_featured.jpg" width=500 height=400>

*****
<img src="https://cdn.thingiverse.com/renders/66/c9/00/99/94/949b6cdfa58337d1874e01b8a00e1348_preview_featured.jpg" width=500 height=400>

******
Bottom view showing air capture plate
*****
<img src="https://cdn.thingiverse.com/renders/91/6a/fb/60/bb/4b2f4b834e9e90b9a6ff87be6ffb0302_preview_featured.jpg" width=500 height=400>






Petsfang mod for Cyclops/ Chimera. Several people are beta testing the prototypes and the results are most promising. 
The fitment is right on.

The base is designed to capture the heat sink air and deflect it out the sides.

Base will have to be printed with full supports