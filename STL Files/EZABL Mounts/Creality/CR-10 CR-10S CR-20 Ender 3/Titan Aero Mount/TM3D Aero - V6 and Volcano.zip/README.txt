There are 2 Aero mounting plates. The EXTENDED one allows for use with slightly larger pancake motors like the 22mm ones TH3D sells. If using the E3D stepper then use the one without EXTENDED in the name.

Make sure to select the correct probe mount in the firmware.