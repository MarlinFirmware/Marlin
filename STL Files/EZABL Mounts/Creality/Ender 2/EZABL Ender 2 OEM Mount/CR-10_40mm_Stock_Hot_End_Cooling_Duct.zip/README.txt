                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2160958
CR-10 40mm Stock Hot End Cooling Duct by superpotatofudge is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

A much lighter weight, more efficient, and quieter fan duct for the Creality CR-10. It is designed to fit the stock Mk8 style red heatsink hot end. It works with the stock cooling fan. It keeps air flow from blowing on the heater block or going anywhere it shouldn't.

Printed as I did it weighs 7g where the stock metal shroud weighs a porky 44g. 

The stock bolts that hold the heatsink to the X carriage are not quite long enough. I used M3x20mm button head screws I had on hand. The stock screws that hold the cooling fan in place will thread nicely into the holes of the printed shroud as they are sized for M3 screws.

I printed with no layer fan as I'm working on a redesign for that also and it came out fine with a few small blobs on the inner support structure and overhangs at the top of the fan opening.

PSA: It has come to my attention that a few people, including myself, experienced the screws going through the shroud loosening over the time of hours worth of printing. Which allows the entire hot end to shift slightly. Make sure you tighten the screws good and tight! And it's not a terrible idea to use a very small amount of BLUE / low strength thread lock on them. 

So because I've seen a fair amount of commentary going around that this shouldn't be printed out of PLA...that's incorrect. PLA is just fine. If your heatsink is getting hot enough to hit the glass transition temperature of PLA then there is seriously something wrong. If the heatsink is getting that hot, you will be experiencing lots of jams because the filament will get swollen and melted inside the tube above the heatbreak.  With that said, feel free to print out of whatever you want. Keep in mind that most PLA experiences around 2-3% shrink rate so it will fit nice and tight, which is good. Printing it out of PETT or PETG should shrink roughly 1% so it may be a bit more loose.

# Print Settings

Printer: Creality CR-10
Rafts: Doesn't Matter
Supports: No
Resolution: 0.2mm
Infill: 10%

Notes: 
Printed with All Professional 3D grey PLA
210C nozzle
55C bed
65mm/s print speed
120mm/s move speed