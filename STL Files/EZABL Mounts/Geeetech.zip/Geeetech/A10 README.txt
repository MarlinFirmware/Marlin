There are 2 versions of the Geeetech A10. The one with a filament sensor is the A10 V2. 
The one without the filament sensor and a 40mm fan on the left side of the hotend is the A10 (V1).
V1 and V2 use different sensor mounts due to the hotend being different.